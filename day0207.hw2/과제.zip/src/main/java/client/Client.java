package client;

import ctrl.Ctrl;

public class Client {
	public static void main(String[] args) {
		Ctrl app = new Ctrl();
		app.startApp();
	}
}
