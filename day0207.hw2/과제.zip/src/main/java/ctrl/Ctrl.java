package ctrl;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import model.DAO;
import view.View;

public class Ctrl {
	private AbstractApplicationContext factory;
	private View view;
	private DAO dao;
	public Ctrl() {
		factory = new GenericXmlApplicationContext("applicationContext.xml");
		view = new View();
		dao = (DAO)factory.getBean("dao");
	}
	public void startApp() {
		while(true) {
			int action = view.printMenu();
			if(action == 1) {
				view.printResult(dao.insert(view.getStr()));
			}
			else if(action == 2) {
				view.printDatas(dao.selectAll());
			}
			else {
				view.powerOff();
				break;
			}
		}
	}
}
