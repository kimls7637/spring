package test;

public interface Remote {
	void on();
	void off();
	void up();
	void down();
}
