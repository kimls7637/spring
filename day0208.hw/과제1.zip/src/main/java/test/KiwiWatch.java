package test;

import org.springframework.stereotype.Component;

@Component("kw")
public class KiwiWatch implements Watch {
	public KiwiWatch() {
		System.out.println("KiwiWatch 객체 생성완");
	}
	public void volumeUp() {
		System.out.println("KiwiWatch로 volumeUp() 수행완");
	}
	public void volumeDown() {
		System.out.println("KiwiWatch로 volumeDown() 수행완");
	}
}
