package test;

public interface Watch {
	void volumeUp();
	void volumeDown();
	// public abstract 생략가능
}
