package test;

public interface Watch {
	void volumeUp();
	void volumeDown();
}
