package com.spring.biz.comment;

public interface CommentService {
}
