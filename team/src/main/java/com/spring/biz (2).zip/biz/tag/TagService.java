package com.spring.biz.tag;

public interface TagService {
}
