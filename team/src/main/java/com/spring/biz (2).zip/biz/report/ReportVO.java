package com.spring.biz.report;

public class ReportVO {
	private int rnum;
	private String rtype;
	private String rid;
	private String rbnum;
	public int getRnum() {
		return rnum;
	}
	public void setRnum(int rnum) {
		this.rnum = rnum;
	}
	public String getRtype() {
		return rtype;
	}
	public void setRtype(String rtype) {
		this.rtype = rtype;
	}
	public String getRid() {
		return rid;
	}
	public void setRid(String rid) {
		this.rid = rid;
	}
	public String getRbnum() {
		return rbnum;
	}
	public void setRbnum(String rbnum) {
		this.rbnum = rbnum;
	}
}
