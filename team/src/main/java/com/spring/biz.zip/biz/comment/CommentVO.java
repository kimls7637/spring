package com.spring.biz.comment;

import java.util.Date;

public class CommentVO {
	private int cnum;
	private int cgroup;
	private int csequence;
	private String ccontent;
	private Date cdate;
	private String cid;
	private int cbnum;
	public int getCnum() {
		return cnum;
	}
	public void setCnum(int cnum) {
		this.cnum = cnum;
	}
	public int getCgroup() {
		return cgroup;
	}
	public void setCgroup(int cgroup) {
		this.cgroup = cgroup;
	}
	public int getCsequence() {
		return csequence;
	}
	public void setCsequence(int csequence) {
		this.csequence = csequence;
	}
	public String getCcontent() {
		return ccontent;
	}
	public void setCcontent(String ccontent) {
		this.ccontent = ccontent;
	}
	
	public Date getCdate() {
		return cdate;
	}
	public void setCdate(Date cdatev) {
		this.cdate = cdatev;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public int getCbnum() {
		return cbnum;
	}
	public void setCbnum(int cbnum) {
		this.cbnum = cbnum;
	}
	
	
	
	

}
