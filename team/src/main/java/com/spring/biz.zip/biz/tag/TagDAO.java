package com.spring.biz.tag;

public class TagDAO {

}
