package com.spring.biz.board;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("boardService")
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private BoardDAO BoardDAO;

	@Override
	public boolean insertBoard(BoardVO bvo) {
		return BoardDAO.insertBoard(bvo);
	}

	@Override
	public boolean updateBoard(BoardVO bvo) {
		return BoardDAO.updateBoard(bvo);
	}

	@Override
	public boolean deleteBoard(BoardVO bvo) {
		return BoardDAO.deleteBoard(bvo);
	}

	@Override
	public List<BoardVO> selectAll_cate_recent(BoardVO bvo) {
		return BoardDAO.selectAll_cate_recent(bvo);
	}

	@Override
	public List<BoardVO> selectAll_cate_hits(BoardVO bvo) {
		return BoardDAO.selectAll_cate_hits(bvo);
	}

	@Override
	public List<BoardVO> selectAll_main_recent(BoardVO bvo) {
		return BoardDAO.selectAll_main_recent(bvo);
	}

	@Override
	public List<BoardVO> selectAll_main_heartCnt(BoardVO bvo) {
		return BoardDAO.selectAll_main_heartCnt(bvo);
	}

	@Override
	public List<BoardVO> selectAll(BoardVO bvo) {
		return BoardDAO.selectAll(bvo);
	}

}
