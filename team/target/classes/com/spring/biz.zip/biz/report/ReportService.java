package com.spring.biz.report;

public interface ReportService {
	public boolean insertReport(ReportVO vo);
	public boolean deleteReport(ReportVO vo);
}
