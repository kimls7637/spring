package test;

public interface Phone {
	void powerOn();
	void powerOff();
	void volumeUp();
	void volumeDown();
}
